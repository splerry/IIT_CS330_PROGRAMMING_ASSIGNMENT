
class security:
    def search(self, user, code):
        detect = False
        str(user)
        str(code)
        for i in range(0, len(user)):
            k = 0
            if user[i] == code[k]:
                if user[i: i + len(code)] == code:
                    detect = True
        return detect

    def skim(self, input) ->str:
        return ''.join([i for i in input if i.isdigit()])

    def generate(self, dig):
        domain = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
        temp = ""
        for i in range(dig):
            temp = temp + str(random.choice(domain))

        return temp


lock_code = "901494"
unlock_code = "901491"

user_code = input("Enter code to lock or unlock: ")
security.skim(security, user_code)

if security.search(security, user_code, lock_code) == True:
    print("Locked")
elif security.search(security, user_code, unlock_code) == True:
    print("Unlocked")
else:
    print("Invalid code sequence entered")